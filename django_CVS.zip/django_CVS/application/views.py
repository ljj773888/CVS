import random

from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.utils import timezone
from activity.models import Activity
from volunteer.models import NormalUser
from .forms import LoginForm, RegisterForm
from .models import Application, Admin
from activity.views import post_activity


def show_activity(request):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif not request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是系统管理员，只有志愿者才能申请活动')
        return render(request, 'volunteer/index.html', locals())
    template_name = 'application/activity_list.html'
    context = {'activity_list': Activity.objects.filter(activity_state=1)}
    return render(request, template_name, context)


def submit_application(request, activity_id):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif not request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是系统管理员，只有志愿者才能申请活动')
        return render(request, 'volunteer/index.html', locals())
    activity = get_object_or_404(Activity, activity_id=activity_id)
    user_id = request.session['user_id']

    user = NormalUser.objects.filter(normal_user_id=user_id).first()
    new_id = generate_application_unique_id()

    application = Application.objects.create(application_id=new_id, admin=activity.admin, normal_user=user,
                                             activity=activity, application_time=timezone.now(), application_state=0,
                                             application_reason="无")
    application.save()
    messages.success(request, '申请成功，请耐心等待活动管理员审核')

    return redirect("application:show_activity")


def register(request):
    register_form = RegisterForm()
    if request.session.get('is_login', None):  # 不允许重复登录
        return render(request, 'volunteer/index.html', locals())  # 自动跳转到首页
    if request.method == "POST":
        register_form = RegisterForm(request.POST)
        if register_form.is_valid():  # 获取数据
            admin_name = register_form.cleaned_data['username']
            password1 = register_form.cleaned_data['password1']
            password2 = register_form.cleaned_data['password2']
            if password1 != password2:  # 判断两次密码是否相同
                message = "两次输入的密码不同！"
                return render(request, 'application/register.html', locals())
            else:
                same_id_cus = Admin.objects.filter(admin_name=admin_name)
                if same_id_cus:  # 用户名唯一
                    message = '用户名已存在'
                    return render(request, 'application/register.html', locals())
                # 当一切都OK的情况下，创建新用户
                else:
                    new_id = generate_normal_user_unique_id()
                    new_cus = Admin.objects.create(admin_id=new_id, admin_name=admin_name, admin_code=password1)
                    new_cus.save()
                    messages.success(request, '注册成功！')
                    # 自动跳转到登录页面
                    login_form = LoginForm()
                    return render(request, 'application/login.html', locals())  # 自动跳转到登录页面
    else:
        return render(request, 'application/register.html', locals())

    return render(request, 'application/register.html', locals())


def login(request):
    login_form = LoginForm()
    if request.session.get('is_login', None):
        return render(request, 'volunteer/index.html', locals())

    if request.method == "POST":
        login_form = LoginForm(request.POST)
        message = "请检查填写的内容！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            user_cus = authenticate_admin(request, username, password)
            if user_cus:
                print(username, password, user_cus.admin_name, user_cus.admin_code)
                messages.success(request, '{}登录成功！欢迎'.format(user_cus.admin_name))
                user_cus.save()
                set_admin_session(request, user_cus)
                return render(request, 'volunteer/index.html', locals())
    return render(request, 'application/login.html', locals())


def check(request):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是志愿者,只有活动管理员才能审核活动')
        return render(request, 'volunteer/index.html', locals())
    template_name = 'application/application_list.html'
    admin = Admin.objects.filter(admin_id=request.session['user_id']).first()
    context = {'application_list': Application.objects.filter(admin=admin)}
    return render(request, template_name, context)


def approve(request, application_id):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是志愿者,只有活动管理员才能审核活动')
        return render(request, 'volunteer/index.html', locals())
    application = Application.objects.filter(application_id=application_id).first()
    application.application_state = 1
    application.check_result = 1
    application.application_time = timezone.now()
    application.save()

    return check(request)


def reject(request, application_id):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是志愿者,只有活动管理员才能审核活动')
        return render(request, 'volunteer/index.html', locals())
    application = Application.objects.filter(application_id=application_id).first()
    application.application_state = 2
    application.check_result = 2
    application.check_time = timezone.now()
    application.save()

    return check(request)


def update(request):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是志愿者,只有活动管理员才能更新活动')
        return render(request, 'volunteer/index.html', locals())
    template_name = 'activity/activity_update.html'
    context = {'activity_list': Activity.objects.all()}
    return render(request, template_name, context)


def delete(request, activity_id):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是志愿者,只有活动管理员才能审核活动')
        return render(request, 'volunteer/index.html', locals())
    Activity.objects.filter(activity_id=activity_id).delete()
    return update(request)


def generate_application_unique_id():
    new_id = str(random.randint(0, 999999999))
    existing_ids = Application.objects.values_list("application_id")
    while new_id in existing_ids:
        new_id = str(random.randint(0, 999999999))
    return new_id


def generate_normal_user_unique_id():
    new_id = str(random.randint(0, 999999999))
    existing_ids = NormalUser.objects.values_list("normal_user_id")
    while new_id in existing_ids:
        new_id = str(random.randint(0, 999999999))
    return new_id


def authenticate_admin(request, admin_name, password):
    try:
        admin_cus = Admin.objects.get(admin_name=admin_name)
        if admin_cus.admin_code == password:
            return admin_cus
        else:
            messages.warning(request, '您输入的密码错误!')
    except Admin.DoesNotExist:
        messages.warning(request, '用户不存在')
    return None


def set_admin_session(request, user_cus):
    request.session['is_login'] = True
    request.session['user_id'] = user_cus.admin_id
    request.session['username'] = user_cus.admin_name
    request.session['is_volunteer'] = False


def check_activity_state(activity_end, current_time):
    activity_end_str = "2023-10-26 22:02:00+08:00"
    current_time = datetime.now(timezone.utc)
    activity_end = datetime.fromisoformat(activity_end_str)
    activity_end = activity_end.astimezone(timezone.utc)
    return activity_end > current_time
