from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import Application, Admin

admin.site.register(Application)
admin.site.register(Admin)
