# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Application(models.Model):
    application_id = models.CharField(primary_key=True, max_length=10, verbose_name="申请序列号")
    admin = models.ForeignKey('Admin', on_delete=models.CASCADE, verbose_name="系统管理员")
    normal_user = models.ForeignKey('volunteer.NormalUser', on_delete=models.CASCADE, verbose_name="志愿者申请")
    activity = models.ForeignKey('activity.Activity', on_delete=models.CASCADE, verbose_name="申请活动")
    application_reason = models.CharField(max_length=50, verbose_name="申请理由")
    application_time = models.DateTimeField(verbose_name="申请时间")
    application_state = models.DecimalField(choices=((0, "尚未审核"), (1, "审核通过"), (2, "审核不通过")), max_digits=4,
                                            decimal_places=0, verbose_name="申请状态",default=0)
    check_result = models.DecimalField(choices=((1, "审核通过"), (2, "审核不通过")), max_digits=4, decimal_places=0,
                                       blank=True, null=True, verbose_name="审核结果")

    class Meta:
        ordering = ['application_id']
        db_table = 'application'
        verbose_name = "活动申请"
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"【{self.normal_user}】申请报名活动【{str(self.activity)}】"


class Admin(models.Model):
    admin_id = models.CharField(primary_key=True, max_length=10, verbose_name="管理员编号")
    admin_name = models.CharField(max_length=10, unique=True, verbose_name="管理员名")
    admin_code = models.CharField(max_length=10, verbose_name="管理员密码")
    check_result = models.DecimalField(choices=((1, "审核通过"), (2, "审核不通过")), max_digits=4, decimal_places=0,
                                       blank=True, null=True, verbose_name="审核结果")
    check_time = models.DateTimeField(blank=True, null=True, verbose_name="审核时间")
    check_back = models.CharField(max_length=50, blank=True, null=True, verbose_name="审核理由")

    class Meta:
        ordering = ['admin_id']
        db_table = 'admin'
        verbose_name = "系统管理员"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.admin_name  # title 换成想显示的属性
