import random
from django.contrib import messages
from django.shortcuts import render, redirect
from application.models import Application
from .forms import LoginForm, RegisterForm
from .models import NormalUser


def register(request):
    register_form = RegisterForm()
    if request.session.get('is_login', None):
        return render(request, 'volunteer/index.html', locals())

    if request.method == "POST":
        register_form = RegisterForm(request.POST)
        if register_form.is_valid():
            username = register_form.cleaned_data['username']
            password1 = register_form.cleaned_data['password1']
            password2 = register_form.cleaned_data['password2']
            organization = register_form.cleaned_data['organization']

            if password1 != password2:
                message = "两次输入密码不一致!"
                return render(request, 'volunteer/register.html', locals())
            else:
                if NormalUser.objects.filter(normal_user_name=username).exists():
                    message = '用户名已存在'
                    return render(request, 'volunteer/register.html', locals())
                else:
                    new_id = generate_unique_user_id()
                    new_normal_user = NormalUser.objects.create(normal_user_id=new_id, normal_user_name=username,
                                                                normal_user_code=password1,
                                                                org=organization, serve_duration=0, average_score=0)
                    new_normal_user.save()
                    messages.success(request, '注册成功!')
                    login_form = LoginForm()
                    return render(request, 'volunteer/login.html', locals())
    else:
        return render(request, 'volunteer/register.html', locals())

    return render(request, 'volunteer/register.html', locals())


def login(request):
    login_form = LoginForm()
    if request.session.get('is_login', None):
        return render(request, 'volunteer/index.html', locals())

    if request.method == "POST":
        login_form = LoginForm(request.POST)
        message = "请检查填写的内容！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            user_cus = authenticate_user(request, username, password)
            if user_cus:
                messages.success(request, '{}登录成功！欢迎'.format(username))
                user_cus.save()
                set_user_session(request, user_cus)
                return render(request, 'volunteer/index.html', locals())
    return render(request, 'volunteer/login.html', locals())


def logout(request):
    if not request.session.get('is_login', None):
        return render(request, 'volunteer/index.html', locals())

    clear_user_session(request)
    messages.success(request, '您已成功退出登录')
    return render(request, 'volunteer/index.html', locals())


def generate_unique_user_id():
    while True:
        new_id = str(random.randint(0, 999999999))
        if not NormalUser.objects.filter(normal_user_id=new_id).exists():
            return new_id


def show_info(request):
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆。要查看个人信息，请先登录')
        return render(request, 'volunteer/index.html', locals())
    return render(request, 'volunteer/show_info.html')


def authenticate_user(request, username, password):
    try:
        user_cus = NormalUser.objects.get(normal_user_name=username)
        if user_cus.normal_user_code == password:
            return user_cus
        else:
            messages.warning(request, '您输入的密码错误!')
    except NormalUser.DoesNotExist:
        messages.warning(request, '用户不存在')
    return None


def set_user_session(request, user_cus):
    request.session['is_login'] = True
    request.session['user_id'] = user_cus.normal_user_id
    request.session['username'] = user_cus.normal_user_name
    request.session['is_volunteer'] = True
    request.session['organization'] = str(user_cus.org)


def clear_user_session(request):
    request.session.flush()


def application_result(request):
    if not request.session.get('is_login', None):
        messages.warning(request, '尚未登陆,查询结果请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif not request.session['is_volunteer']:
        messages.warning(request, '您现在以活动管理员身份登入，以志愿者身份登入才能查询自己全部申请结果')
        return render(request, 'volunteer/index.html', locals())
    volunteer = NormalUser.objects.filter(normal_user_id=request.session['user_id']).first()
    template_name = 'volunteer/application_list.html'
    context = {'application_list': Application.objects.filter(normal_user=volunteer)}
    return render(request, template_name, context)
