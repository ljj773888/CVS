from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import Comment, NormalUser, Organization

admin.site.register(Comment)
admin.site.register(NormalUser)
admin.site.register(Organization)