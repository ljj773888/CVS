# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Comment(models.Model):
    comment_id = models.CharField(primary_key=True, max_length=10, verbose_name="服务评价序列号")
    activity = models.ForeignKey('activity.Activity', on_delete=models.CASCADE, verbose_name="评价活动")
    admin = models.ForeignKey('application.Admin', on_delete=models.CASCADE, verbose_name="评价操作管理员")
    normal_user = models.ForeignKey('NormalUser', models.DO_NOTHING, verbose_name="评价对象")
    serve_hour = models.FloatField(verbose_name="本次活动服务时长")
    score = models.FloatField(verbose_name="评价对象")
    serve_comment = models.CharField(max_length=20, verbose_name="服务评语")

    class Meta:
        ordering = ['comment_id']
        db_table = 'comment'
        verbose_name = "服务评价"
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"对【{self.normal_user}】完成活动【{self.activity}】的评价"  # title 换成想显示的属性


class NormalUser(models.Model):
    normal_user_id = models.CharField(primary_key=True, max_length=10, verbose_name="用户编号")
    org = models.ForeignKey('Organization', models.DO_NOTHING, verbose_name="义工组织")
    normal_user_name = models.CharField(max_length=10, unique=True, verbose_name="用户名")
    normal_user_code = models.CharField(max_length=20, verbose_name="用户密码")
    serve_duration = models.FloatField(verbose_name="累计志愿时长")
    average_score = models.FloatField(verbose_name="平均服务分数")
    normal_user_state = models.BooleanField("用户状态", default=True)

    class Meta:
        ordering = ['normal_user_id']
        db_table = 'normal_user'
        verbose_name = "志愿者"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.normal_user_name  # title 换成想显示的属性


class Organization(models.Model):
    org_id = models.CharField(primary_key=True, max_length=10, verbose_name="义工组织号")
    org_name = models.CharField(max_length=20, verbose_name="义工组织名")

    class Meta:
        ordering = ['org_id']
        db_table = 'organization'
        verbose_name = "义工组织"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.org_name  # title 换成想显示的属性
