from django.contrib import admin

# Register your models here.
from django.contrib import admin

from .models import Activity, ActivityLabel, Place

admin.site.register(Activity)
admin.site.register(ActivityLabel)
admin.site.register(Place)