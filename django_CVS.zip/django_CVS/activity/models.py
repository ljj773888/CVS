# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Activity(models.Model):
    activity_id = models.CharField(primary_key=True, max_length=10, verbose_name="志愿活动号")
    activity_label = models.ForeignKey('ActivityLabel', on_delete=models.CASCADE, verbose_name="活动标签")
    address = models.ForeignKey('Place', on_delete=models.CASCADE, verbose_name="活动地址")
    admin = models.ForeignKey('application.Admin', on_delete=models.CASCADE, verbose_name="管理员",)
    activity_name = models.CharField(max_length=20, verbose_name="志愿活动名")
    activity_introduction = models.CharField(max_length=50, verbose_name="活动介绍")
    activity_address = models.CharField(max_length=50, verbose_name="活动地点")
    activity_people_num = models.IntegerField(verbose_name="活动人数")
    activity_request = models.CharField(max_length=50, verbose_name="活动要求")
    activity_begin = models.DateTimeField(verbose_name="开始时间")
    activity_end = models.DateTimeField(verbose_name="结束时间")
    activity_state = models.DecimalField(choices=((0, "活动未开始"), (1, "正在报名"), (2, "已过期")), max_digits=4,
                                         decimal_places=0, verbose_name="活动状态")

    class Meta:
        ordering = ['activity_id']
        db_table = 'activity'
        verbose_name = "志愿活动"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.activity_name  # title 换成想显示的属性


class ActivityLabel(models.Model):
    activity_label_id = models.CharField(primary_key=True, max_length=10, verbose_name="活动标签号")
    activity_label_name = models.CharField(max_length=20, unique=True, verbose_name="活动标签名")

    class Meta:
        ordering = ['activity_label_id']
        db_table = 'activity_label'
        verbose_name = "活动标签"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.activity_label_name  # title 换成想显示的属性


class Place(models.Model):
    address_id = models.CharField(primary_key=True, max_length=10, verbose_name="活动地址号")
    address = models.CharField(max_length=100, unique=True, verbose_name="活动地址")

    class Meta:
        ordering = ['address_id']
        db_table = 'place'
        verbose_name = "举办地点"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.address  # title 换成想显示的属性
