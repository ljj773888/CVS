from django import forms

from .models import ActivityLabel, Place


class ActivityForm(forms.Form):
    activity_type = forms.ModelChoiceField(queryset=ActivityLabel.objects.all(), required=True)
    location = forms.ModelChoiceField(queryset=Place.objects.all(), required=True)
    activity_name = forms.CharField(label="志愿活动名", max_length=20, widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': "请填写志愿活动名", 'autofocus': ''}))
    activity_introduction = forms.CharField(label="活动介绍", max_length=50, widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': "请填写活动介绍", 'autofocus': ''}))
    activity_requirements = forms.CharField(label="活动要求", max_length=50, widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': "请填写活动要求", 'autofocus': ''}))
    activity_start_time = forms.DateTimeField(
        input_formats=['%Y/%m/%d %H:%M:%S'],
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control datetimepicker-input',
            'data-target': '#datetimepicker1'
        })
    )
    activity_end_time = forms.DateTimeField(
        input_formats=['%Y/%m/%d %H:%M:%S'],
        widget=forms.DateTimeInput(attrs={
            'class': 'form-control datetimepicker-input',
            'data-target': '#datetimepicker2'
        })
    )
    headcount = forms.IntegerField()
