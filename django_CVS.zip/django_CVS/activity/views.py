import random
from datetime import datetime, timezone
from django.contrib import messages
from django.shortcuts import render
from application.models import Admin
from .forms import ActivityForm
from .models import Activity


def show_activity(request):
    template_name = 'activity/activity_list.html'
    context = {'activity_list': Activity.objects.all()}
    return render(request, template_name, context)


def post_activity(request):
    activity_form = ActivityForm()
    if not request.session.get('is_login', None):
        messages.success(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.success(request, '检测到您当前身份是志愿者,只有系统管理员才能发布活动')
        return render(request, 'volunteer/index.html', locals())

    if request.method == "POST":
        activity_form = ActivityForm(request.POST)
        if activity_form.is_valid():  # 获取数据
            new_id = generate_unique_id()
            admin = Admin.objects.filter(admin_id=request.session['user_id']).first()
            activity_label = activity_form.cleaned_data['activity_type']
            address = activity_form.cleaned_data['location']
            activity_name = activity_form.cleaned_data['activity_name']
            activity_introduction = activity_form.cleaned_data['activity_introduction']
            activity_request = activity_form.cleaned_data['activity_requirements']
            activity_begin = activity_form.cleaned_data['activity_start_time']
            activity_end = activity_form.cleaned_data['activity_end_time']
            activity_people_num = activity_form.cleaned_data['headcount']
            if datetime.now().replace(tzinfo=None) < activity_end.replace(tzinfo=None):
                print("yes")
                activity_state = 1
            else:
                print("no")
                activity_state = 2
            new_activity = Activity.objects.create(
                activity_id=new_id, activity_label=activity_label,
                address=address, admin=admin,
                activity_name=activity_name, activity_state=activity_state,
                activity_introduction=activity_introduction, activity_request=activity_request,
                activity_begin=activity_begin, activity_end=activity_end,
                activity_people_num=activity_people_num
            )
            request.session['activity_id'] = new_id
            new_activity.save()
            messages.success(request, '发布活动成功!')
            return show_activity(request)
        else:
            return render(request, 'activity/post_activity.html', locals())

    return render(request, 'activity/post_activity.html', locals())


def modify(request, activity_id):
    activity_form = ActivityForm()
    if not request.session.get('is_login', None):
        messages.warning(request, '您尚未登陆,请先登录')
        return render(request, 'volunteer/index.html', locals())
    elif request.session['is_volunteer']:
        messages.warning(request, '检测到您当前身份是志愿者,只有活动管理员才能审核活动')
        return render(request, 'volunteer/index.html', locals())
    if request.method == "POST":
        activity_form = ActivityForm(request.POST)
        if activity_form.is_valid():  # 获取数据
            activity = Activity.objects.filter(activity_id=activity_id).first()
            activity.activity_label = activity_form.cleaned_data['activity_type']
            activity.address = activity_form.cleaned_data['location']
            activity.activity_name = activity_form.cleaned_data['activity_name']
            activity.activity_introduction = activity_form.cleaned_data['activity_introduction']
            activity.activity_request = activity_form.cleaned_data['activity_requirements']
            activity.activity_begin = activity_form.cleaned_data['activity_start_time']
            activity.activity_end = activity_form.cleaned_data['activity_end_time']
            activity.activity_people_num = activity_form.cleaned_data['headcount']
            if datetime.now().replace(tzinfo=None) < activity.activity_end.replace(tzinfo=None):
                print("yes")
                activity.activity_state = 1
            else:
                print("no")
                activity.activity_state = 2
            activity.save()
            messages.success(request, '修改活动成功!')
            return show_activity(request)
        else:
            return render(request, 'application/post_activity.html', locals())
    return render(request, "application/post_activity.html", locals())


def generate_unique_id():
    new_id = str(random.randint(0, 999999999))
    existing_ids = Activity.objects.values_list("activity_id")
    while new_id in existing_ids:
        new_id = str(random.randint(0, 999999999))
    return new_id


